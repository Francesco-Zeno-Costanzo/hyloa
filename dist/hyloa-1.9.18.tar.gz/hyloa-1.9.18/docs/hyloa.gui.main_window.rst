hyloa.gui.main\_window module
==================================

.. automodule:: hyloa.gui.main_window
   :members:
   :undoc-members:
   :show-inheritance:
