hyloa.gui.log\_window module
==================================

.. automodule:: hyloa.gui.log_window
   :members:
   :undoc-members:
   :show-inheritance:
