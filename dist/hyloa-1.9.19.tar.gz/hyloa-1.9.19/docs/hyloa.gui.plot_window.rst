hyloa.gui.plot\_window module
==================================

.. automodule:: hyloa.gui.plot_window
   :members:
   :undoc-members:
   :show-inheritance:
